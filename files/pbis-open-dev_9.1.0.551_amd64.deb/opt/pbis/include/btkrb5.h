#include <keytab.h>
#include <ktldap.h>

